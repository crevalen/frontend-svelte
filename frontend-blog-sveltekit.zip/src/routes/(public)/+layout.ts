// src/routes/(public)/+layout.ts

export const prerender = false;