-- AlterTable
ALTER TABLE "Media" ADD COLUMN     "url_placeholder" TEXT;
