-- AlterTable
ALTER TABLE "Media" ADD COLUMN     "url_medium" TEXT,
ADD COLUMN     "url_thumb" TEXT;
