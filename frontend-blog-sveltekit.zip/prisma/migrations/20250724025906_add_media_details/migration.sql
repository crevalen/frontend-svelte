-- AlterTable
ALTER TABLE "Media" ADD COLUMN     "caption" TEXT,
ADD COLUMN     "filename" TEXT,
ADD COLUMN     "title" TEXT;
